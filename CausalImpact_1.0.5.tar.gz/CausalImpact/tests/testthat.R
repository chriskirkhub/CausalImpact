library(testthat)
library(CausalImpact)

test_check("CausalImpact")
